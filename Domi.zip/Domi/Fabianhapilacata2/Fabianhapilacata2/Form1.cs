﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fabianhapilacata2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            numericUpDown1.Minimum = 1;      // Minimum value
            numericUpDown1.Maximum = 9999999999;    // Maximum value
            numericUpDown1.Increment = 1;    // Step size (increment)
            numericUpDown1.DecimalPlaces = 0; // No decimal places
            MessageBox.Show("Ai cumparat : " + numericUpDown1.Value + " radiere si a costat 10 lei");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Facut de Alupului Robert pentru Hriscu Dominic");
        }
    }
}
