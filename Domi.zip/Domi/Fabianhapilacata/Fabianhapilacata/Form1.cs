﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fabianhapilacata
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ai cumparat posca mov");

            MessageBox.Show("A costat 90 de lei");



        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ai cumparat posca negru");

            MessageBox.Show("A costat 100 de lei");



        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
           

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ai cumparat posca albastru");
            MessageBox.Show("A costat 190 de lei");

        }
    }
}
